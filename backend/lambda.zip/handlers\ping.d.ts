import { APIGatewayProxyHandler } from "aws-lambda";
export declare const handler: APIGatewayProxyHandler;
//# sourceMappingURL=ping.d.ts.map